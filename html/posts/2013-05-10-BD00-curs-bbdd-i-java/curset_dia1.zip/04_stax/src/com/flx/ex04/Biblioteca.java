package com.flx.ex04;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.xml.stream.*;
import javax.xml.stream.events.*;

public class Biblioteca {
	private List<Llibre> llibres;
	
	public Biblioteca() { llibres = new ArrayList<Llibre>(); }
	
	public void buidar() { llibres.clear(); }
	
	public void afegirLlibre(Llibre unLlibre) { llibres.add(unLlibre); }
	
	public void llistarLlibres() {
		System.out.println("\n\nLlistat de llibres (total " + llibres.size() + ")");
		System.out.println("-------------------------------------\n");
		for (Llibre l : llibres) {
			System.out.println(l.toString());
		}
	}
	
	@SuppressWarnings("unchecked")
	public void carregarXML(String nomArxiu) throws Exception {
		buidar();
		XMLEventReader er = XMLInputFactory.newInstance()
				.createXMLEventReader(new InputStreamReader(
						new FileInputStream(nomArxiu), "UTF-8"));
		
		Llibre llibre = null;
		while (er.hasNext()) {
			XMLEvent e = er.nextEvent();
			if (e.isStartElement()) {
				StartElement se = e.asStartElement();
				if (se.getName().getLocalPart().equals("llibre")) {
					llibre = new Llibre();
					Iterator<Attribute> attrs = se.getAttributes();
					while (attrs.hasNext()) {
						Attribute attr = attrs.next();
						if (attr.getName().toString().equals("isbn")) {
							llibre.setIsbn(attr.getValue());
						}
					}
				}
				else if (se.getName().getLocalPart().equals("idioma")) {
					e = er.nextEvent();
					llibre.setIdioma(e.asCharacters().getData());
				}
				else if (se.getName().getLocalPart().equals("titol")) {
					e = er.nextEvent();
					llibre.setTitol(e.asCharacters().getData());
				}
				else if (se.getName().getLocalPart().equals("autor")) {
					e = er.nextEvent();
					llibre.setAutor(e.asCharacters().getData());
				}
			}
			else if (e.isEndElement()) {
				if (e.asEndElement().getName().getLocalPart().equals("llibre")) {
					afegirLlibre(llibre);
				}
			}
		}
	}

	public void desarXML(String nomArxiu) throws Exception {
	    XMLEventWriter ew = XMLOutputFactory.newInstance()
	    		.createXMLEventWriter(new OutputStreamWriter(
	    				new FileOutputStream(nomArxiu), "UTF-8"));
		XMLEventFactory ef = XMLEventFactory.newInstance();

	    ew.add(ef.createStartDocument());
	    XMLEvent end = ef.createSpace("\n");
		XMLEvent tab = ef.createSpace("\t");
	    ew.add(end);
	    ew.add(ef.createDTD("<!DOCTYPE biblioteca SYSTEM \"biblio.dtd\">"));
	    ew.add(end);
	    ew.add(ef.createComment("Un exemple de base de dades bibliogràfica"));
	    ew.add(end);
	    ew.add(ef.createStartElement("", "", "biblioteca"));
	    ew.add(end);

	    for (Llibre l : llibres) {
			ArrayList<Attribute> attrList = new ArrayList<Attribute>();
			attrList.add(ef.createAttribute("isbn", l.getIsbn()));
		    attrList.add(ef.createAttribute("idioma", l.getIdioma()));
		    ew.add(tab);
		    ew.add(ef.createStartElement("", "", "llibre", attrList.iterator(), null));
		    ew.add(end);
			ew.add(tab); ew.add(tab);
			ew.add(ef.createStartElement("", "", "titol"));
			ew.add(ef.createCData(l.getTitol()));
			ew.add(ef.createEndElement("", "", "titol"));
			ew.add(end);
			ew.add(tab); ew.add(tab);
			ew.add(ef.createStartElement("", "", "autor"));
			ew.add(ef.createCharacters(l.getAutor()));
			ew.add(ef.createEndElement("", "", "autor"));
			ew.add(end);
			ew.add(tab);
			ew.add(ef.createEndElement("", "", "llibre"));
			ew.add(end);
	    }
	    
		ew.add(ef.createEndElement("", "", "biblioteca"));
		ew.add(end);
		ew.add(ef.createEndDocument());
		ew.close();
	}
}

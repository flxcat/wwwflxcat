package com.flx.ex04;

public class Llibre {
	private String isbn;
	private String idioma;
	private String titol;
	private String autor;
	
	public void setIsbn(String isbn) { this.isbn = isbn; }
	public void setIdioma(String idioma) { this.idioma = idioma; }
	public void setTitol(String titol) { this.titol = titol; }
	public void setAutor(String autor) { this.autor = autor; }
	
	public String getIsbn() { return isbn; }
	public String getIdioma() { return idioma; }
	public String getTitol() { return titol; }
	public String getAutor() { return autor; }
	
	public String toString() {
		return autor + ", " + titol + " (" + idioma + ") ISBN:" + isbn;
	}
}

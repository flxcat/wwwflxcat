package com.flx.ex04;

public class ProvaBiblioteca {

	public static void main(String[] args) {
		// Carreguem la biblioteca des del disc
		Biblioteca b = new Biblioteca();
		try {
			b.carregarXML("biblio.xml");
		} catch (java.lang.Exception e) {
			System.err.println("No s'ha pogut llegir l'arxiu de biblioteca!");
			e.printStackTrace(System.err);
			System.exit(1);
		}
		b.llistarLlibres();
		
		// Afegim dos llibres més a la biblioteca
		Llibre l1 = new Llibre();
		l1.setIsbn("978-84-615-9841-0");
		l1.setTitol("Oracle SQL és fàcil!");
		l1.setAutor("Fèlix Galindo Allué");
		l1.setIdioma("ca");
		b.afegirLlibre(l1);
		Llibre l2 = new Llibre();
		l2.setIsbn("0-13-027363-5");
		l2.setTitol("Thinking in Java");
		l2.setAutor("Bruce Eckel");
		l2.setIdioma("en");
		b.afegirLlibre(l2);
		b.llistarLlibres();
		
		// Desem el nou arxiu de biblioteca
		try {
			b.desarXML("biblio2.xml");
		} catch (java.lang.Exception e) {
			System.err.println("No s'ha pogut escriure l'arxiu de biblioteca!");
			e.printStackTrace(System.err);
			System.exit(1);
		}
	}
}

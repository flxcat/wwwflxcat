package com.flx.ex02;

import java.sql.*;
import javax.swing.*;

public class EnviarSQL {

	public static void mostrarDetallsExcepcio(SQLException se, boolean warning) {
		if (warning)
			System.err.println( "SQL Warning:" );
		else
			System.err.println( "SQL Exception:" );
		while ( se != null ) {
			System.err.println( "State  : " + se.getSQLState()  );
			System.err.println( "Message: " + se.getMessage()   );
			System.err.println( "Error  : " + se.getErrorCode() );
			se = se.getNextException();
		}
	}

	public static Connection connectar(String driver, String db_url, 
			String user, String pwd) throws Exception {
		Connection conn = null;
		Class.forName(driver);
		conn = DriverManager.getConnection(db_url ,user, pwd);
		SQLWarning warn = conn.getWarnings();
		if (warn != null)
			mostrarDetallsExcepcio(warn, true);
		return conn;
	}

	public static void ajuda() {
		System.out.println("Ús: EnviarSQL host dbname user password sql");
		System.out.println();
		System.out.println("Envia la sentència SQL especificada al servidor MySQL");
		System.out.println("del servidor indicat, amb la base de dades i l'usuari");
		System.out.println("i contrasenya indicats.");
		System.out.println();
		System.out.print("P.ex.: EnviarSQL localhost hr hr_user hr_pass ");
		System.out.println("'SELECT * FROM employees'");
	}

	public static String padLeft(String text, int n) {
		return String.format("%1$" + n + "s", text);
	}

	public static String padRight(String text, int n) {
		return String.format("%1$-" + n + "s", text);
	}

	public static void mostrarTaula(ResultSet rs) {
		try {
			// MUNTEM CAPÇALERA
			ResultSetMetaData rsmd = rs.getMetaData();
			String header = "";
			String sep = "";
			for ( int i = 0; i < rsmd.getColumnCount(); i++ ) {
				String col = rsmd.getColumnName(i+1); // ATENCIÓ: COMENÇA AMB 1
				int mida = rsmd.getColumnDisplaySize(i+1);
				if ( rsmd.getColumnTypeName(i+1).matches(".*INT") ||
						rsmd.getColumnTypeName(i+1).matches("DATE") ) {
					col = padLeft(col, mida);
				}
				else {
					col = padRight(col, mida);
				}
				col = col.substring(0, mida);
				if (header.length() != 0) {
					header += " | ";
					sep += "-+-";
				}
				header += col.toUpperCase();
				sep += padLeft("", col.length()).replace(" ", "-");
			}
			System.out.println("+-" + sep + "-+");
			System.out.println("| " + header + " |");
			System.out.println("+-" + sep + "-+");

			// MOSTREM DADES
			int n = 0;
			while( rs.next() ) {
				++n;
				String text = "";
				for ( int i = 0; i < rsmd.getColumnCount(); i++ ) {
					Object obj = rs.getObject(i+1);
					String col = "";
					if (obj != null)
						col = obj.toString();
					int mida = rsmd.getColumnDisplaySize(i+1);
					if ( rsmd.getColumnTypeName(i+1).matches(".*INT") ||
							rsmd.getColumnTypeName(i+1).matches("DATE") ) {
						col = padLeft(col, mida);
					}
					else {
						col = padRight(col, mida);
					}
					col = col.substring(0, mida);
					if (text.length() != 0) {
						text += " | ";
					}
					text += col;
				}
				System.out.println("| " + text + " |" );
			}
			System.out.println("+-" + sep + "-+");
			System.out.println( n + " files mostrades.");
			System.out.println();
		}
		catch( SQLException se ) { mostrarDetallsExcepcio(se, false); }
		catch( Exception e ) { e.printStackTrace(); }
	}

	public static void main( String args[] ) {
		String host = null;
		String dbname = null;
		String user = null;
		String password = null;
		String sql = null;
		if (args.length == 0) {
			host = JOptionPane.showInputDialog("Hostname:");
			dbname = JOptionPane.showInputDialog("Database:");
			user = JOptionPane.showInputDialog("User:");
			password = JOptionPane.showInputDialog("Password:");
			sql = JOptionPane.showInputDialog("SQL:");
		}
		else if ( args.length != 5 ) { 
			ajuda();
			System.exit(1);
		}
		else {
			host = args[0];
			dbname = args[1];
			user = args[2];
			password = args[3];
			sql = args[4];
		}
		String url = "jdbc:mysql://" + host + "/" + dbname;
		try {
			System.out.println("Contactant la base de dades...");
			Connection conn = connectar( "com.mysql.jdbc.Driver", url, user, password );
			System.out.println("Connexió establerta!");
			System.out.println();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			mostrarTaula(rs);
			rs.close();
			stmt.close();
			conn.close();
		}
		catch( SQLException se ) { mostrarDetallsExcepcio(se, false); }
		catch( Exception e ) { e.printStackTrace(); }
	}
}

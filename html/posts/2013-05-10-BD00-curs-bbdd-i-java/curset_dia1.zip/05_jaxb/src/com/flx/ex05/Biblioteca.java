package com.flx.ex05;

import java.io.File;
import java.util.ArrayList;
import javax.xml.bind.*;
import javax.xml.bind.annotation.*;

@XmlRootElement(name = "biblioteca")
public class Biblioteca {
	private ArrayList<Llibre> llibres;
	
	public void setBiblioteca(ArrayList<Llibre> llibres) { this.llibres = llibres; }
	
	@XmlElement(name = "llibre")
	public ArrayList<Llibre> getBiblioteca() { return llibres; }
	
	public Biblioteca() { llibres = new ArrayList<Llibre>(); }
	
	public void afegirLlibre(Llibre unLlibre) { llibres.add(unLlibre); }
	
	public void llistarLlibres() {
		System.out.println("\n\nLlistat de llibres (total " + llibres.size() + ")");
		System.out.println("-------------------------------------\n");
		for (Llibre l : llibres) {
			System.out.println(l.toString());
		}
	}
	
	public static Biblioteca carregarXML(String nomArxiu) throws Exception {
		JAXBContext ctx = JAXBContext.newInstance(Biblioteca.class);
	    Unmarshaller um = ctx.createUnmarshaller();
	    Biblioteca b = (Biblioteca)um.unmarshal(new File(nomArxiu));
	    return b;
	}
	
	public void desarXML(String nomArxiu) throws Exception {
		JAXBContext ctx = JAXBContext.newInstance(Biblioteca.class);
	    Marshaller m = ctx.createMarshaller();
	    m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	    m.marshal(this, new File(nomArxiu));
	}
}

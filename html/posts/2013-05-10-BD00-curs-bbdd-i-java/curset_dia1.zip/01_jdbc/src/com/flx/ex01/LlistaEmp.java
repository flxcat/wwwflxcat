package com.flx.ex01;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.SQLWarning;
import java.sql.Statement;

public class LlistaEmp {
	public static void mostrarDetallsExcepcio( SQLException se, boolean warning ) {
		if (warning) {
			System.err.println( "SQL Warning:" );
		}
		else {
			System.err.println( "SQL Exception:" );
		}
		while ( se != null ) {
			System.err.println( "State  : " + se.getSQLState()  );
			System.err.println( "Message: " + se.getMessage()   );
			System.err.println( "Error  : " + se.getErrorCode() );
			se = se.getNextException();
		}
	}

	public static Connection connectar( String driver, String db_url, 
			String user, String pwd ) throws Exception {
		Connection conn = null;
		Class.forName( driver );
		conn = DriverManager.getConnection( db_url ,user, pwd );
		SQLWarning warn = conn.getWarnings();
		if ( warn != null ) {
			mostrarDetallsExcepcio( warn, true );
		}
		return conn;
	}

	public static void main( String args[] ) {
		try {
			System.out.println( "Contactant la base de dades..." );
			Connection conn = connectar( "com.mysql.jdbc.Driver", 
					"jdbc:mysql://localhost/hr",
					"hr_user",
					"hr_pass" );
			System.out.println( "Connexió establerta!" );
			System.out.println();
			String sql = "SELECT * FROM employees";
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			while( rs.next() ) {
				int id  = rs.getInt("employeeId");
				String nom = rs.getString("firstname");
				String cognoms = rs.getString("lastname");
				System.out.println( id + ": " + cognoms + ", " + nom );
			}
			System.out.println();
			rs.close();
			stmt.close();
			conn.close();
		}
		catch( SQLException se ) { mostrarDetallsExcepcio(se, false); }
		catch( Exception e ) { e.printStackTrace(); }
	}
}

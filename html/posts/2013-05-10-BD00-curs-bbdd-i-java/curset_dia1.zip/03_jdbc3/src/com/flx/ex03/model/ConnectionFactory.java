package com.flx.ex03.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

  // paràmetres de JDBC
  final String driverClassName = "com.mysql.jdbc.Driver";
  final String connectionUrl = "jdbc:mysql://localhost:3306/hr";
  final String dbUser = "hr_user";
  final String dbPwd = "hr_pass";

  // Constructor
  private ConnectionFactory() {
    try {
      Class.forName(driverClassName);
    } catch (ClassNotFoundException e) {
      System.err.println(e.getMessage());
    }
  }

  // Singleton per a obtenir la connexió
  private static ConnectionFactory connectionFactory = null;
  public static ConnectionFactory getInstance() {
    if (connectionFactory == null) {
      connectionFactory = new ConnectionFactory();
    }
    return connectionFactory;
  }

  // obtenir una connexió JDBC activa
  public Connection getConnection() throws SQLException {
    Connection conn = null;
    conn = DriverManager.getConnection(connectionUrl, dbUser, dbPwd);
    return conn;
  }
}

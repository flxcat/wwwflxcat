package com.flx.ex03.model;

import java.util.Date;

public class Employee {
	int employeeId;
	String firstname;
	String lastname;
	String email;
	String phoneINT;
	Date hireDate;
	String jobId;
	float salary;
	float commissionPct;
	int managerId;
	int departmentId;

	public Employee(int employeeId, String firstname, String lastname, 
			String email, String phoneINT, Date hireDate, 
			String jobId, float salary, float commissionPct, 
			int managerId, int departmentId) {
		this.employeeId = employeeId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.phoneINT = phoneINT;
		this.hireDate = hireDate;
		this.jobId = jobId;
		this.salary = salary;
		this.commissionPct = commissionPct;
		this.managerId = managerId;
		this.departmentId = departmentId;
	}
	
	public int getEmployeeId() { return employeeId; }
	public String getFirstname() { return firstname; }
	public String getLastname() { return lastname; }
	public String getEmail() { return email; }
	public String getPhoneINT() { return phoneINT; }
	public Date getHireDate() { return hireDate; }
	public String getJobId() { return jobId; }
	public float getSalary() { return salary; }
	public float getCommissionPct() { return commissionPct; }
	public int getManagerId() { return managerId; }
	public int getDepartmentId() { return departmentId; }

	public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }
	public void setFirstname(String firstname) { this.firstname = firstname; }
	public void setLastname(String lastname) { this.lastname = lastname; }
	public void setEmail(String email) { this.email = email; }
	public void setPhoneINT(String phoneINT) { this.phoneINT = phoneINT; }
	public void setHireDate(Date hireDate) { this.hireDate = hireDate; }
	public void setJobId(String jobId) { this.jobId = jobId; }
	public void setSalary(float salary) { this.salary = salary; }
	public void setCommissionPct(float commissionPct) { this.commissionPct = commissionPct; }
	public void setManager(int managerId) { this.managerId = managerId; }
	public void setDepartment(int departmentId) { this.departmentId = departmentId; }
}

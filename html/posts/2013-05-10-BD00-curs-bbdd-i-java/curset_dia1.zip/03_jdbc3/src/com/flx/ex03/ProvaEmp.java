package com.flx.ex03;

import com.flx.ex03.model.*;

public class ProvaEmp {
	public static void main( String args[] ) {
		HrDAO hrdao = new HrDAO();
		
		final int empId = 101;
		
		Employee e1 = hrdao.findEmployeeById(empId);
		System.out.println(e1.getLastname() + " cobra " + e1.getSalary());
		
		System.out.println("Augmentem el sou en un 5%");
		e1.setSalary(e1.getSalary() * 1.05f);
		hrdao.updateEmployeeById(empId, e1); // Aquest mètode fallarà...
		
		Employee e2 = hrdao.findEmployeeById(empId);
		System.out.println(e2.getLastname() + " cobra " + e2.getSalary());
	}
}

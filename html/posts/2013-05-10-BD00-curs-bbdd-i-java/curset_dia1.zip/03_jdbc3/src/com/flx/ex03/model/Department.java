package com.flx.ex03.model;

public class Department {
	int departmentId;
	String departmentName;
	int managerId;
	int locationId;
	
	public Department(int departmentId, String departmentName, int managerId, int locationId) {
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.managerId = managerId;
		this.locationId = locationId;
	}
	
	public int getDepartmentId() { return departmentId; }
	public String getDepartmentName() { return departmentName; }
	public int getManagerId() { return managerId; }
	public int getLocationId() { return locationId; }
	
	public void setDepartmentId(int departmentId) { this.departmentId = departmentId; }
	public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }
	public void setManagerId(int managerId) { this.managerId = managerId; }
	public void setLocationId(int locationId) { this.locationId = locationId; }
}

package com.flx.ex03.model;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

public class HrDAO {

	private Connection getConnection() throws SQLException {
		Connection conn;
		conn = ConnectionFactory.getInstance().getConnection();
		return conn;
	}

	public HrDAO() { }

	private List<Employee> getEmployeesFromSQL(String sql) {
		List<Employee> list = new ArrayList<Employee>();
		try {
			ResultSet resultSet = getConnection().createStatement().executeQuery(sql);
			while (resultSet.next()) {
				int employeeId = resultSet.getInt("employeeId");
				String firstname = resultSet.getString("firstname");
				String lastname = resultSet.getString("lastname");
				String email = resultSet.getString("email");
				String phoneINT = resultSet.getString("phoneINT");
				Date hireDate = resultSet.getDate("hireDate");
				String jobId = resultSet.getString("jobId");
				float salary = resultSet.getFloat("salary");
				float commissionPct = resultSet.getFloat("commissionPct");
				int managerId = resultSet.getInt("managerId");
				int departmentId = resultSet.getInt("departmentId");
				list.add(new Employee(employeeId, firstname, lastname, email,
						phoneINT, hireDate, jobId, salary, commissionPct,
						managerId, departmentId));
			}
		}
		catch(SQLException e) {
			System.err.println(e.getMessage());
		}
		return list;
	}

	public List<Employee> findAllEmployees() {
		String sql = "SELECT * FROM employees";
		return getEmployeesFromSQL(sql);
	}

	public List<Employee> findEmployeesByDepartment(int departmentId) {
		String sql = "SELECT * FROM employees WHERE departmentId='" + departmentId + "'";
		return getEmployeesFromSQL(sql);
	}

	public Employee findEmployeeById(int employeeId) {
		String sql = "SELECT * FROM employees WHERE employeeId=" + employeeId;
		List<Employee> list = getEmployeesFromSQL(sql);
		if (list.size() != 1) return null;
		Employee emp = list.get(0);
		return emp;
	}

	// Funció que modifica la informació d'un usuari concret
	public boolean updateEmployeeById(int employeeId, Employee emp) {
		boolean ok = false;
		try {
			String sql = "UPDATE employees SET ";
			sql += "employeeId=" + emp.getEmployeeId() + ", ";
			sql += "firstname='" + emp.getFirstname() + "', ";
			sql += "lastname='" + emp.getLastname() + "', ";
			sql += "email='" + emp.getEmail() + "', ";
			sql += "phoneINT='" + emp.getPhoneINT() + "', ";
			sql += "hireDate='" + emp.getHireDate() + "', ";
			sql += "jobId='" + emp.getJobId() + "', ";
			sql += "salary=" + emp.getSalary() + ", ";
			sql += "commissionPct=" + emp.getCommissionPct() + ", ";
			sql += "managerId=" + emp.getManagerId() + ", ";
			sql += "departmentId=" + emp.getDepartmentId() + " ";
			sql += "WHERE employeeId=" + employeeId + "";
			//System.out.println(sql);
			Statement stmt = getConnection().createStatement();
			stmt.execute(sql);
			ok = (stmt.getUpdateCount() == 1);
		}
		catch(SQLException e) {
			System.err.println(e.getMessage());
		}
		return ok;
	}

	public void add(Employee emp) {
		try {
			String sql = "INSERT INTO employees VALUES (";
			sql += "" + emp.getEmployeeId() + ", ";
			sql += "'" + emp.getFirstname() + "', ";
			sql += "'" + emp.getLastname() + "', ";
			sql += "'" + emp.getEmail() + "', ";
			sql += "'" + emp.getPhoneINT() + "', ";
			sql += "'" + emp.getHireDate() + "', ";
			sql += "'" + emp.getJobId() + "', ";
			sql += "" + emp.getSalary() + ", ";
			sql += "" + emp.getCommissionPct() + ", ";
			sql += "" + emp.getManagerId() + ", ";
			sql += "" + emp.getDepartmentId() + ")";
			getConnection().createStatement().execute(sql);
		}
		catch(SQLException e) {
			System.err.println(e.getMessage());
		}
	}
}

package com.flx.ex08.model;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name="employees")
public class Employee {
	private int employeeId;
	private String firstname;
	private String lastname;
	private String email;
	private String phoneINT;
	private Date hireDate;
	private String jobId;
	private Float salary;
	private Float commissionPct;
	private Employee manager;
	private Department department;

	public Employee() { }
	
	public Employee(int employeeId, String firstname, String lastname, 
			String email, String phoneINT, Date hireDate, 
			String jobId, Float salary, Float commissionPct, 
			Employee manager, Department department) {
		this.employeeId = employeeId;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.phoneINT = phoneINT;
		this.hireDate = hireDate;
		this.jobId = jobId;
		this.salary = salary;
		this.commissionPct = commissionPct;
		this.manager = manager;
		this.department = department;
	}

	@Id
	@GeneratedValue
	public int getEmployeeId() { return employeeId; }
	public String getFirstname() { return firstname; }
	public String getLastname() { return lastname; }
	public String getEmail() { return email; }
	public String getPhoneINT() { return phoneINT; }
	public Date getHireDate() { return hireDate; }
	public String getJobId() { return jobId; }
	public Float getSalary() { return salary; }
	public Float getCommissionPct() { return commissionPct; }
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="managerId")
	public Employee getManager() { return manager; }
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="departmentId")
	public Department getDepartment() { return department; }

	public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }
	public void setFirstname(String firstname) { this.firstname = firstname; }
	public void setLastname(String lastname) { this.lastname = lastname; }
	public void setEmail(String email) { this.email = email; }
	public void setPhoneINT(String phoneINT) { this.phoneINT = phoneINT; }
	public void setHireDate(Date hireDate) { this.hireDate = hireDate; }
	public void setJobId(String jobId) { this.jobId = jobId; }
	public void setSalary(Float salary) { this.salary = salary; }
	public void setManager(Employee manager) { this.manager = manager; }
	public void setCommissionPct(Float commissionPct) { this.commissionPct = commissionPct; }
	public void setDepartment(Department department) { this.department = department; }

	public String toString() {
		return employeeId + " : " + lastname + ", " + firstname + " / " + jobId + " (" + salary + ")";
	}

}


package com.flx.ex08;

import com.flx.ex08.model.*;

import java.util.Calendar;
import javax.swing.JOptionPane;

public class DAOHibernateTest4 {

	public static void main(String[] args) {
		// Iniciem els DAO
		HrDAOHibernateJPA hrDAO = new HrDAOHibernateJPA();
		hrDAO.setUp();
		
		// Si el registre existia, l'esborrem
		Employee anna = hrDAO.findEmployeeByLastname("Rovirosa");
		if (anna != null) {
			hrDAO.deleteEmployee(anna);
		}
		
		// El definim de nou i inserim
		Calendar hiredate = Calendar.getInstance();
		hiredate.set(2005, 06, 17);
		Employee nouEmp = new Employee(0, "Anna", "Rovirosa", 
				"annar@hr.com", "12345678", hiredate.getTime(), "AC_MGR", 
				17000.0f, (Float)null, (Employee)null, (Department)null);
		hrDAO.insertEmployee(nouEmp);
		
		// Preguntem el tant per cent d'augment de sous
		float percent = 0;
		boolean ok = false;
		while (!ok) {
			String resp = JOptionPane.showInputDialog("Percentatge d'augment de salari:");
			try {
				percent = Float.parseFloat(resp);
				ok = true;
			}
			catch(NumberFormatException nfe) { }
		}
		
		// Modifiquem els sous dels treballadors
		for (Employee emp : hrDAO.findAllEmployees()) {
			emp.setSalary(emp.getSalary() * (1 + percent/100));
			hrDAO.updateEmployee(emp);
		}
		
		// Mostrem la llista de treballadors, obtenint-la de nou
		for (Employee e : hrDAO.findAllEmployees()) {
			System.out.println(e);
		}
	}
}

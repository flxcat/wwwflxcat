package com.flx.ex08;

import com.flx.ex08.model.*;

import javax.swing.JOptionPane;

public class DAOHibernateTest3 {

	public static void main(String[] args) {
		// Iniciem els DAO
		HrDAOHibernateJPA hrDAO = new HrDAOHibernateJPA();
		hrDAO.setUp();
		
		Employee emp = null;
		while (emp == null) {
			String resp = JOptionPane.showInputDialog("Id del treballador:");
			try {
				int id = Integer.parseInt(resp);
				emp = hrDAO.findEmployeeById(id);
			}
			catch(NumberFormatException nfe) { }
		}
		
		// Informació bàsica del treballador
		System.out.println(emp);
		
		// Arbre de jerarquia (resseguint els caps)
		Employee mgr = emp.getManager();
		while (mgr != null) {
			System.out.println("  que treballa per: " + mgr);
			mgr = mgr.getManager();
		}
		
		// Informació del departament en què treballa
		Department dept = emp.getDepartment();
		System.out.println();
		System.out.println("DEPARTAMENT: " + dept);
		Employee deptMgr = dept.getManager();
		System.out.println("  amb cap: " + deptMgr);
	}
}

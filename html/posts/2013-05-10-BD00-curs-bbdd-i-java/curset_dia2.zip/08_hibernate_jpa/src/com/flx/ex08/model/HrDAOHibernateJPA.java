package com.flx.ex08.model;

import java.util.List;
import javax.persistence.*;
import javax.persistence.criteria.*;


public class HrDAOHibernateJPA {

	static EntityManager em = null;
	static CriteriaBuilder cb = null;
	public void setUp() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("mngr1");
		em = emf.createEntityManager();
		cb = em.getCriteriaBuilder();
	}

	public HrDAOHibernateJPA() { }

	public List<Employee> findAllEmployees() {
		CriteriaQuery<Employee> query = cb.createQuery(Employee.class);
        Root<Employee> emp = query.from(Employee.class);
        query.orderBy(cb.asc(emp.get("lastname")), cb.desc(emp.get("firstname")));
        List<Employee> emps = em.createQuery(query).getResultList();
        return emps;
	}
	
	public Employee findEmployeeById(int employeeId) {
		CriteriaQuery<Employee> query = cb.createQuery(Employee.class);
        Root<Employee> emp = query.from(Employee.class);
        query.where(cb.equal(emp.get("employeeId"), employeeId));
        List<Employee> emps = em.createQuery(query).getResultList();
        if (emps.size() != 1) return null;
        else return emps.get(0);
	}
	
	public Employee findEmployeeByLastname(String lastname) {
		CriteriaQuery<Employee> query = cb.createQuery(Employee.class);
        Root<Employee> emp = query.from(Employee.class);
        query.where(cb.equal(emp.get("lastname"), lastname));
        List<Employee> emps = em.createQuery(query).getResultList();
        if (emps.size() != 1) return null;
        else return emps.get(0);
	}
	
	public Department findDepartmentById(int departmentId) {
		CriteriaQuery<Department> query = cb.createQuery(Department.class);
        Root<Department> emp = query.from(Department.class);
        query.where(cb.equal(emp.get("departmentId"), departmentId));
        List<Department> depts = em.createQuery(query).getResultList();
        if (depts.size() != 1) return null;
        else return depts.get(0);
	}
	
	// INSERCIÓ D'UN EMPLOYEE
	public void insertEmployee(Employee emp) {
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
	}

	// MODIFICACIÓ D'UN EMPLOYEE
	public void updateEmployee(Employee emp) {
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();
	}
	
	// ELIMINACIÓ D'UN EMPLOYEE
	public void deleteEmployee(Employee emp) {
		em.getTransaction().begin();
		em.remove(emp);
		em.getTransaction().commit();
	}
}

package com.flx.ex06.model;

public class Department {
	private int departmentId;
	private String departmentName;
	private Employee manager;
	private Integer locationId;
	
	public Department() { }
	
	public Department(int departmentId, String departmentName, Employee manager, Integer locationId) {
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.manager = manager;
		this.locationId = locationId;
	}
	
	public int getDepartmentId() { return departmentId; }
	public String getDepartmentName() { return departmentName; }
	public Employee getManager() { return manager; }
	public Integer getLocationId() { return locationId; }
	
	public void setDepartmentId(int departmentId) { this.departmentId = departmentId; }
	public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }
	public void setManager(Employee manager) { this.manager = manager; }
	public void setLocationId(Integer locationId) { this.locationId = locationId; }

	public String toString() {
		return departmentName + " (" + departmentId + ")";
	}
}

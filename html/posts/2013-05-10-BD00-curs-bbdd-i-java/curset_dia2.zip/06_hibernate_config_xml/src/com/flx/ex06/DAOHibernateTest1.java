package com.flx.ex06;

import com.flx.ex06.model.*;

public class DAOHibernateTest1 {

	public static void main(String[] args) {
		// iniciem els DAO
		HrDAOHibernate hrDAO = new HrDAOHibernate();
		
		// Llistem els treballadors
		for(Employee emp : hrDAO.findAllEmployees()) {
			System.out.println(emp);
		}
	}
}

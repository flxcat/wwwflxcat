package com.flx.ex07;

import com.flx.ex07.model.*;

public class DAOHibernateTest1 {

	public static void main(String[] args) {
		// iniciem els DAO
		HrDAOHibernate hrDAO = new HrDAOHibernate();
		
		// Llistem els treballadors
		for(Employee emp : hrDAO.findAllEmployees()) {
			System.out.println(emp);
		}
	}
}

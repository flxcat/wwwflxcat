package com.flx.ex07;

import com.flx.ex07.model.*;

public class DAOHibernateTest2 {

	public static void main(String[] args) {
		// iniciem els DAO
		HrDAOHibernate hrDAO = new HrDAOHibernate();
		
		// Llistem els treballadors
		for(Employee emp : hrDAO.findAllEmployees()) {
			System.out.print(emp);
			Department dept = emp.getDepartment();
			if (dept == null) {
				System.out.println(" -> SENSE DEPARTAMENT!");
			}
			else {
				System.out.print(" -> " + dept);
				Employee deptManager = dept.getManager();
				if (deptManager == null) {
					System.out.println(" -> SENSE CAP DE DEPT.!");
				}
				else {
					System.out.println(" -> " + deptManager);
				}
			}
		}
	}
}

package com.flx.ex07.model;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HrDAOHibernate {

    private static Session session = null;
    public static Session getSession() {
        if (session == null) {
            ServiceRegistry serviceRegistry;
            Configuration configuration = new Configuration();
            configuration.configure();
            serviceRegistry = new ServiceRegistryBuilder()
                .applySettings(configuration.getProperties())
                .buildServiceRegistry();        
            SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
        	session = sessionFactory.openSession();
        }
        return session;
    }
    
    public void cleanup() {
    	if (session != null) {
    		session.close();
    		session = null;
    	}
    }

	public HrDAOHibernate() { }

	// MITJANÇANT CRITERIA
	public List<Employee> findAllEmployees() {
	    Session session = getSession();
        session.beginTransaction();
        Criteria c = session.createCriteria(Employee.class)
                            .addOrder(Order.asc("lastname"));
        @SuppressWarnings("unchecked")
        List<Employee> emps = c.list();
        session.getTransaction().commit();
        return emps;
	}
	
	// MITJANÇANT SQL
	public Employee findEmployeeById(int employeeId) {
	    Session session = getSession();
        session.beginTransaction();
        SQLQuery q = session.createSQLQuery("SELECT * FROM employees e WHERE employeeId=" + employeeId);
        Employee emp = (Employee) q.addEntity(Employee.class).uniqueResult();
        session.getTransaction().commit();
        return emp;
	}
	
	// MITJANÇANT SQL
	public Employee findEmployeeByLastname(String lastname) {
	    Session session = getSession();
        session.beginTransaction();
        SQLQuery q = session.createSQLQuery("SELECT * FROM employees e WHERE lastname=?");
        q.setString(0, lastname);
        Employee emp = (Employee) q.addEntity(Employee.class).uniqueResult();
        session.getTransaction().commit();
        return emp;
	}
	
	// MITJANÇANT CRITERIA
	public Department findDepartmentById(int departmentId) {
	    Session session = getSession();
        session.beginTransaction();
        Criteria c = session.createCriteria(Department.class)
        		.add(Restrictions.eq("departmentId", departmentId))
                .addOrder(Order.asc("lastname"));
        Department dept = (Department) c.uniqueResult();
        session.getTransaction().commit();
        return dept;
	}
	
	// INSERCIÓ D'UN EMPLOYEE
	public void insertEmployee(Employee emp) {
		Session session = getSession();
		session.beginTransaction();
		session.save(emp);
		session.getTransaction().commit();
	}

	// MODIFICACIÓ D'UN EMPLOYEE
	public void updateEmployee(Employee emp) {
		Session session = getSession();
		session.beginTransaction();
		session.update(emp);
		session.getTransaction().commit();
	}
	
	// ELIMINACIÓ D'UN EMPLOYEE
	public void deleteEmployee(Employee emp) {
		Session session = getSession();
		session.beginTransaction();
		session.delete(emp);
		session.getTransaction().commit();
	}
}

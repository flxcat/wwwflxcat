import org.basex.server.ClientSession;
import org.basex.server.ClientQuery;

public class Test02 {

  public static void main(String[] args) {
    try {
      long t1 = System.currentTimeMillis();
      ClientSession sessio = 
    		  new ClientSession("localhost", 1984, "admin", "admin");
      String query = 
        "doc('mondial.xml')//mondial/country[name='Spain']" +
                    "/province[name='Catalonia']/city/name";
      ClientQuery clientQuery = sessio.query(query);
      String result = clientQuery.execute();
      long t2 = System.currentTimeMillis();
      System.out.println(result);
      System.out.println();
      System.out.println("Executat en " + (t2-t1) + "ms");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}

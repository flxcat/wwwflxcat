public class Test03 {

  public static void main(String[] args) {
    try {
      long t1 = System.currentTimeMillis();
      BaseXClient sessio = 
    		  new BaseXClient("localhost", 1984, "admin", "admin");
      String query = 
        "XQUERY doc('mondial.xml')//mondial/country[name='Spain']" +
                           "/province[name='Catalonia']/city/name";
      String result = sessio.execute(query);
      long t2 = System.currentTimeMillis();
      System.out.println(result);
      System.out.println();
      System.out.println("Executat en " + (t2-t1) + "ms");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}

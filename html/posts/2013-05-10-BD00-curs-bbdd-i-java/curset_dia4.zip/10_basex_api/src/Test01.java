import org.basex.core.Context;
import org.basex.core.cmd.XQuery;

public class Test01 {
  static Context context = new Context();

  public static void main(String[] args) {
    try {
      long t1 = System.currentTimeMillis();
      String query = 
        "doc('mondial.xml')//mondial/country[name='Spain']" +
                    "/province[name='Catalonia']/city/name";
      String result = new XQuery(query).execute(context);
      long t2 = System.currentTimeMillis();
      System.out.println(result);
      System.out.println();
      System.out.println("Executat en " + (t2-t1) + "ms");
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }
}

package com.flx.ex09.model;

import java.util.List;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;

public class HRDAOdb4o {
	ObjectContainer db;
	public ObjectContainer getDB() { return db; }

	public void connect(String dbFile) {
		db = Db4oEmbedded.openFile(Db4oEmbedded.newConfiguration(), dbFile);
	}
	
	public void close() {
		db.close();
	}
	
	public List<Employee> findAllEmployees() {
		List<Employee> result = db.queryByExample(Employee.class);
		return result;
	}
	
	public List<Department> findAllDepartments() {
		List<Department> result = db.queryByExample(Department.class);
		return result;
	}
	
	@SuppressWarnings("serial")
	public Employee findEmployeeById(int id) {
		final int empId = id;
		List<Employee> emps = db.query(new Predicate<Employee>() {
			public boolean match(Employee emp) {
				return (emp.getEmployeeId() == empId);
			}
		});
		if (emps.size() != 1) return null;
		else return emps.get(0);
	}

	@SuppressWarnings("serial")
	public Department findDepartmentById(int id) {
		final int deptId = id;
		List<Department> depts = db.query(new Predicate<Department>() {
			public boolean match(Department dept) {
				return (dept.getDepartmentId() == deptId);
			}
		});
		if (depts.size() != 1) return null;
		else return depts.get(0);
	}

	public void store(Object o) { db.store(o); }
}

package com.flx.ex09;

import com.flx.ex09.model.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLWarning;
import java.sql.Statement;

public class CopyFromMySQL {
	
	public static Connection connectJDBC( String driver, String db_url, 
			String user, String pwd ) throws Exception {
		Connection conn = null;
		Class.forName( driver );
		conn = DriverManager.getConnection( db_url ,user, pwd );
		SQLWarning warn = conn.getWarnings();
		if ( warn != null ) {
			System.err.println( warn.getMessage());
		}
		return conn;
	}
	
	public static void main(String[] args) {
		// Eliminem primer la base de dades (si existia)
		new java.io.File("testDB.db4o").delete();
		// La creem de nou, connectant-nos-hi
		HRDAOdb4o hrDAO = new HRDAOdb4o();
		hrDAO.connect("testDB.db4o");
		
		try {
			// Obrim connexió JDBC amb la base de dades MySQL per capturar les dades
			Connection jdbc = connectJDBC("com.mysql.jdbc.Driver", "jdbc:mysql://localhost/hr", "hr_user", "hr_pass");
			Statement stmt = jdbc.createStatement();

			// Passem els departments, sense manager
			ResultSet rsDept = stmt.executeQuery( "SELECT * FROM departments" );
			while( rsDept.next() ) {
				Department dept = new Department(
						rsDept.getInt("departmentId"),
						rsDept.getString("departmentName"),
						null,
						rsDept.getInt("locationId"));
				hrDAO.store(dept);
			}
			rsDept.close();
			
			// Ara definim els employees, omplint els department respectius
			ResultSet rsEmp = stmt.executeQuery("SELECT * FROM employees");
			while( rsEmp.next() ) {
				int managerId = rsEmp.getInt("managerId");
				Employee manager = hrDAO.findEmployeeById(managerId);
				int departmentId = rsEmp.getInt("departmentId");
				Department department = hrDAO.findDepartmentById(departmentId);
				Employee emp = new Employee(
						rsEmp.getInt("employeeId"),
						rsEmp.getString("firstname"),
						rsEmp.getString("lastname"),
						rsEmp.getString("email"),
						rsEmp.getString("phoneINT"),
						rsEmp.getDate("hireDate"),
						rsEmp.getString("jobId"),
						rsEmp.getFloat("salary"),
						rsEmp.getFloat("commissionPct"),
						manager,
						department);
				hrDAO.store(emp);
			}
			rsEmp.close();
			
			// Tornem al ResultSet de departaments i el tornem a
			// repassar per assignar els caps de departament
			ResultSet rsDept2 = stmt.executeQuery( "SELECT * FROM departments" );
			while( rsDept2.next() ) {
				int departmentId = rsDept2.getInt("departmentId");
				Department department = hrDAO.findDepartmentById(departmentId);
				int managerId = rsDept2.getInt("managerId");
				Employee manager = hrDAO.findEmployeeById(managerId);
				department.setManager(manager);
				hrDAO.store(department);
			}
			rsDept2.close();

			stmt.close();

			// Mostrem els departaments
			for (Department d : hrDAO.findAllDepartments()) {
				System.out.println(d);
			}

			// Mostrem els employees
			for (Employee e : hrDAO.findAllEmployees()) {
				System.out.println(e);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			hrDAO.close();
		}
	}

}
